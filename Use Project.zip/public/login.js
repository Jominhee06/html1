document.getElementById('loginButton').addEventListener('click', async () => {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('errorMessage');

    // 오류 메시지 초기화
    errorMessage.style.display = 'none';

    // 사용자 이름과 비밀번호 입력 확인
    if (!username || !password) {
        errorMessage.textContent = '사용자 이름과 비밀번호를 입력하세요.';
        errorMessage.style.display = 'block';
        return;
    }

    // 서버로 로그인 요청
    try {
        const response = await fetch('http://localhost:5000/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password }),
        });

        if (response.ok) {
            const data = await response.json();
            localStorage.setItem('token', data.token);
            window.location.href = 'recipe-title.html'; // 레시피 제목 페이지로 이동
        } else {
            const errorData = await response.json();
            errorMessage.textContent = errorData.message || '로그인 실패: 사용자 이름 또는 비밀번호가 잘못되었습니다.';
            errorMessage.style.display = 'block';
        }
    } catch (error) {
        console.error('로그인 요청 중 오류 발생:', error);
        errorMessage.textContent = '서버 오류가 발생했습니다. 나중에 다시 시도해 주세요.';
        errorMessage.style.display = 'block';
    }
});

