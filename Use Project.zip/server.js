const express = require('express');
const path = require('path');
const app = express();
const PORT = 5000; // PORT를 환경변수로 설정, 기본값은 5000

// 미들웨어 설정
app.use(express.json()); // JSON 요청 처리
app.use(express.static(path.join(__dirname, 'public'))); // 정적 파일 제공 (public 폴더에서)

// 메인 페이지에 대해 index.html 제공
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html')); // 메인 페이지
});

// 로그인 페이지
app.get('/login.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// 등록 페이지
app.get('/register.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

// 레시피 페이지
app.get('/recipes.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'recipes.html'));
});

//ingredients.html에 대한 라우팅
app.get('/ingredients.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'ingredients.html'));
});

// 가상의 메모리 사용자 데이터 (향후 데이터베이스 논리로 교체 가능)
const users = [{ username: 'admin', password: 'password' }];
const recipes = [];

// 인증 경로 (가상 로그인)
app.post('/auth/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        return res.json({ token: 'fake-jwt-token' }); // 가짜 토큰 제공 (향후 용도)
    } else {
        return res.status(401).json({ message: '잘못된 자격 증명' });
    }
});

// 등록 경로 (가상 등록)
app.post('/auth/register', (req, res) => {
    const { username, password } = req.body;
    const userExists = users.some(u => u.username === username);

    if (!userExists) {
        users.push({ username, password });
        res.status(201).json({ message: '사용자가 성공적으로 등록되었습니다.' });
    } else {
        res.status(400).json({ message: '이미 존재하는 사용자입니다.' });
    }
});

// 모든 레시피 가져오기
app.get('/recipes', (req, res) => {
    res.json(recipes);
});

// 새 레시피 추가
app.post('/recipes', (req, res) => {
    const { title, category, ingredients, instructions } = req.body;
    const newRecipe = { id: recipes.length + 1, title, category, ingredients, instructions };
    recipes.push(newRecipe);
    res.status(201).json({ message: '레시피가 성공적으로 추가되었습니다.', recipe: newRecipe });
});

// 레시피 수정
app.put('/recipes/:id', (req, res) => {
    const { id } = req.params;
    const { title, category, ingredients, instructions } = req.body;
    const recipeIndex = recipes.findIndex(r => r.id === parseInt(id));

    if (recipeIndex !== -1) {
        recipes[recipeIndex] = { id: parseInt(id), title, category, ingredients, instructions };
        res.json({ message: '레시피가 성공적으로 수정되었습니다.', recipe: recipes[recipeIndex] });
    } else {
        res.status(404).json({ message: '레시피를 찾을 수 없습니다.' });
    }
});

// 레시피 삭제
app.delete('/recipes/:id', (req, res) => {
    const { id } = req.params;
    const recipeIndex = recipes.findIndex(r => r.id === parseInt(id));

    if (recipeIndex !== -1) {
        const deletedRecipe = recipes.splice(recipeIndex, 1);
        res.json({ message: '레시피가 성공적으로 삭제되었습니다.', recipe: deletedRecipe[0] });
    } else {
        res.status(404).json({ message: '레시피를 찾을 수 없습니다.' });
    }
});

// 서버 시작
app.listen(PORT, () => {
    console.log(`서버가 http://localhost:${PORT} 실행 중입니다.`);
});








